#!/usr/bin/env bash

java -jar build/libs/my-bot.jar -p "$1" -i "$2"