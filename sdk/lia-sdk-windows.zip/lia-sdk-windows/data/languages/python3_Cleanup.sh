#!/usr/bin/env bash

cd "$1"
rm -r venv