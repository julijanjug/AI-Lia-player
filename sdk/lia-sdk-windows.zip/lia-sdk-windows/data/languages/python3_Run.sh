#!/usr/bin/env bash

venv/bin/python3 my_bot.py -p "$1" -i "$2"
