#!/usr/bin/env bash

cd "$1"
chmod +x gradlew
./gradlew build