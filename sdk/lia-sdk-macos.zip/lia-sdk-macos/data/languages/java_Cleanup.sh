#!/usr/bin/env bash

cd "$1"
rm -r build
rm -r .gradle